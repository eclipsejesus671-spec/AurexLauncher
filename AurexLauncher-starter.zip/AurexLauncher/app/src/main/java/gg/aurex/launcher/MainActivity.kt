package gg.aurex.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Gold = Color(0xFFFFD34D)
private val DeepGold = Color(0xFFB8860B)
private val Black = Color(0xFF101010)
private val Panel = Color(0xFF202020)
private val Blue = Color(0xFF16A9FF)
private val TextLight = Color(0xFFF4F4F4)
private val Muted = Color(0xFFB7B7B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AurexApp() }
    }
}

@Composable
fun AurexApp() {
    var page by remember { mutableStateOf("Home") }
    var version by remember { mutableStateOf("1.21.11") }
    var profile by remember { mutableStateOf("Default") }
    var message by remember { mutableStateOf("Aurex Launcher UI prototype") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Blue, background = Black, surface = Panel,
        onPrimary = Black, onBackground = TextLight, onSurface = TextLight
    )) {
        Column(Modifier.fillMaxSize().background(Black)) {
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).border(2.dp, Gold, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("A", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("AUREX", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("LAUNCHER", color = Blue, fontSize = 11.sp, letterSpacing = 4.sp)
                }
                IconButton(onClick = { page = "Settings" }) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Gold)
                }
            }
            Row(Modifier.fillMaxWidth().height(3.dp).background(Gold)) {}
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (page) {
                    "Home" -> {
                        Text("CURRENT PROFILE", color = Muted, fontSize = 12.sp)
                        PanelCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(36.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(profile, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Local profile", color = Muted, fontSize = 13.sp)
                                }
                                Text("›", color = Gold, fontSize = 30.sp)
                            }
                        }
                        Text("MINECRAFT VERSION", color = Muted, fontSize = 12.sp)
                        PanelCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(version, color = TextLight, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    Text("Selected version", color = Muted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { page = "Versions" }) {
                                    Icon(Icons.Default.ExpandMore, null, tint = Gold)
                                }
                            }
                        }
                        Button(
                            onClick = { message = "Minecraft backend not connected yet. This button is ready to be wired to a compatible launcher engine." },
                            modifier = Modifier.fillMaxWidth().height(62.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, null)
                            Spacer(Modifier.width(8.dp))
                            Text("LAUNCH", fontSize = 20.sp, fontWeight = FontWeight.Black)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NavTile("Accounts", Icons.Default.Person, Modifier.weight(1f)) { page = "Accounts" }
                            NavTile("Versions", Icons.Default.Layers, Modifier.weight(1f)) { page = "Versions" }
                            NavTile("Settings", Icons.Default.Settings, Modifier.weight(1f)) { page = "Settings" }
                        }
                        PanelCard {
                            Text("READY FOR YOUR NEXT WORLD?", color = Gold, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text("Gold and blue branding. Dark, simple, mobile-first.", color = Muted)
                        }
                        Text(message, color = Blue, fontSize = 12.sp)
                    }
                    "Versions" -> {
                        PageTitle("Versions")
                        listOf("1.21.11", "1.21.10", "1.21.9", "1.21.8", "1.20.6", "1.20.4").forEach { v ->
                            PanelCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ViewInAr, null, tint = Gold)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(v, fontWeight = FontWeight.Bold)
                                        Text("Version selection UI only", color = Muted, fontSize = 12.sp)
                                    }
                                    RadioButton(selected = version == v, onClick = { version = v }, colors = RadioButtonDefaults.colors(selectedColor = Gold))
                                }
                            }
                        }
                    }
                    "Accounts" -> {
                        PageTitle("Accounts")
                        PanelCard {
                            Text(profile, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("Local profile placeholder", color = Muted)
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(value = profile, onValueChange = { profile = it }, label = { Text("Player name") }, singleLine = true)
                        }
                        Text("Microsoft sign-in is not implemented in this starter project.", color = Muted, fontSize = 13.sp)
                    }
                    else -> {
                        PageTitle("Settings")
                        PanelCard {
                            Text("Java runtime", color = Gold, fontWeight = FontWeight.Bold)
                            Text("Needs a compatible Minecraft launcher backend and Java runtime integration.", color = Muted)
                        }
                        PanelCard {
                            Text("Memory allocation", color = Gold, fontWeight = FontWeight.Bold)
                            Text("Will be configurable after backend integration.", color = Muted)
                        }
                        PanelCard {
                            Text("Theme", color = Gold, fontWeight = FontWeight.Bold)
                            Text("Gold #FFD34D  •  Blue #16A9FF  •  Black #101010", color = Muted)
                        }
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("Home" to Icons.Default.Home, "Accounts" to Icons.Default.Person, "Versions" to Icons.Default.Layers, "Settings" to Icons.Default.Settings).forEach { (label, icon) ->
                    Column(
                        Modifier.weight(1f).clickable { page = label }.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(icon, contentDescription = label, tint = if (page == label) Gold else Muted)
                        Text(label, color = if (page == label) Gold else Muted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp))
            .border(1.dp, DeepGold.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun NavTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.background(Panel, RoundedCornerShape(10.dp))
            .border(1.dp, DeepGold, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick).padding(vertical = 18.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Gold, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(8.dp))
        Text(label, color = TextLight, fontSize = 12.sp)
    }
}

@Composable
fun PageTitle(text: String) {
    Text(text, color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
}
